---
name: Monochrome Retail Logic
colors:
  surface: '#f9f9f9'
  surface-dim: '#dadada'
  surface-bright: '#f9f9f9'
  surface-container-lowest: '#ffffff'
  surface-container-low: '#f3f3f3'
  surface-container: '#eeeeee'
  surface-container-high: '#e8e8e8'
  surface-container-highest: '#e2e2e2'
  on-surface: '#1b1b1b'
  on-surface-variant: '#4c4546'
  inverse-surface: '#303030'
  inverse-on-surface: '#f1f1f1'
  outline: '#7e7576'
  outline-variant: '#cfc4c5'
  surface-tint: '#5e5e5e'
  primary: '#000000'
  on-primary: '#ffffff'
  primary-container: '#1b1b1b'
  on-primary-container: '#848484'
  inverse-primary: '#c6c6c6'
  secondary: '#5e5e5e'
  on-secondary: '#ffffff'
  secondary-container: '#e1dfdf'
  on-secondary-container: '#626262'
  tertiary: '#000000'
  on-tertiary: '#ffffff'
  tertiary-container: '#1b1b1b'
  on-tertiary-container: '#848484'
  error: '#ba1a1a'
  on-error: '#ffffff'
  error-container: '#ffdad6'
  on-error-container: '#93000a'
  primary-fixed: '#e2e2e2'
  primary-fixed-dim: '#c6c6c6'
  on-primary-fixed: '#1b1b1b'
  on-primary-fixed-variant: '#474747'
  secondary-fixed: '#e4e2e2'
  secondary-fixed-dim: '#c7c6c6'
  on-secondary-fixed: '#1b1c1c'
  on-secondary-fixed-variant: '#464747'
  tertiary-fixed: '#e2e2e2'
  tertiary-fixed-dim: '#c6c6c6'
  on-tertiary-fixed: '#1b1b1b'
  on-tertiary-fixed-variant: '#474747'
  background: '#f9f9f9'
  on-background: '#1b1b1b'
  surface-variant: '#e2e2e2'
typography:
  display:
    fontFamily: Inter
    fontSize: 32px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: -0.02em
  h1:
    fontFamily: Inter
    fontSize: 24px
    fontWeight: '600'
    lineHeight: '1.3'
  h2:
    fontFamily: Inter
    fontSize: 20px
    fontWeight: '600'
    lineHeight: '1.3'
  body-lg:
    fontFamily: Inter
    fontSize: 16px
    fontWeight: '400'
    lineHeight: '1.5'
  body-sm:
    fontFamily: Inter
    fontSize: 14px
    fontWeight: '400'
    lineHeight: '1.5'
  label-bold:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '700'
    lineHeight: '1.2'
    letterSpacing: 0.05em
  label-mono:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '500'
    lineHeight: '1.2'
  status-critical:
    fontFamily: Inter
    fontSize: 12px
    fontWeight: '900'
    lineHeight: '1'
rounded:
  sm: 0.125rem
  DEFAULT: 0.25rem
  md: 0.375rem
  lg: 0.5rem
  xl: 0.75rem
  full: 9999px
spacing:
  unit: 4px
  xs: 4px
  sm: 8px
  md: 16px
  lg: 24px
  xl: 48px
  gutter: 16px
  margin-mobile: 16px
  margin-desktop: 32px
---

## Brand & Style
The design system is rooted in the "Utility Minimalism" movement. It prioritizes clarity and rapid information processing for high-volume retail environments. The brand personality is clinical, efficient, and authoritative, evoking a sense of organized precision. 

The aesthetic draws from Modernist Swiss design, utilizing a strict monochrome palette to eliminate visual noise. The goal is to create a tool that feels as essential and transparent as a receipt or a ledger. By removing color, the interface directs the user's focus entirely toward the data—expiry dates and stock levels—using weight and contrast as the primary drivers of hierarchy.

## Colors
The palette is strictly grayscale to maintain a professional, high-contrast environment. 

- **Primary:** Pure black (#000000) for core text, primary buttons, and critical iconography.
- **Secondary/Neutral:** A range of grays from #666666 for metadata to #F9F9F9 for subtle surface layering.
- **Accents:** In extreme cases where functional clarity requires it (such as a destructive action or a singular "critical" focus), a deep blue-black or a single subtle accent tone may be used, though high-contrast patterns (e.g., diagonal stripes or inverted blocks) are the preferred method for status indication.
- **Surface:** The background is paper-white (#FFFFFF) to maximize whitespace impact and legibility.

## Typography
The design system utilizes **Inter** for its exceptional legibility and neutral, systematic character. 

Typography is the primary vehicle for visual hierarchy. Headlines are set in bold weights with tight letter spacing for a modern, editorial feel. Functional data (like expiry dates and SKU numbers) utilize tabular numerals to ensure vertical alignment in lists. To replace color-coded statuses, "Critical" or "Expired" indicators use heavy weights (Black 900) and uppercase transformations to demand attention without breaking the monochrome aesthetic.

## Layout & Spacing
The layout follows a strict 8px soft grid system. Content is structured within a fluid grid that utilizes generous margins (24px+) to prevent the interface from feeling cluttered.

Spacing rhythm is used to group related items: 4px–8px for internal element relationships (label to input) and 24px–48px for section separation. The "WhatsApp-style" simplicity is achieved through a single-column vertical flow on mobile and a structured multi-pane layout on desktop, emphasizing a clear, linear path for scanning inventory items.

## Elevation & Depth
Depth is conveyed through **low-contrast outlines** and tonal layering rather than heavy shadows.

- **Level 0 (Base):** Pure white (#FFFFFF) background.
- **Level 1 (Cards/Containers):** A thin 1px border (#E2E2E2) with no shadow.
- **Level 2 (Active/Floating):** A very subtle, highly diffused ambient shadow (0px 4px 20px, 4% opacity black) to suggest a slight lift for modals or active search bars.
- **Selection:** Elements are "elevated" through inversion—turning the background black and the text white—to indicate focus or selection.

## Shapes
The shape language is "Soft-Modern." Corners are clipped with a 0.25rem (4px) radius to maintain a professional, architectural feel while being more approachable than sharp 90-degree angles. This subtle rounding prevents the interface from feeling overly aggressive or industrial, maintaining the user-friendly vibe of a modern utility app.

## Components
- **Buttons:** Primary buttons are solid black with white text. Secondary buttons are white with a 1px gray border. No gradients.
- **Expiry Status Indicators:**
    - *Healthy:* Standard weight, medium gray text.
    - *Expiring Soon:* Bold weight, black text, 1px black underline.
    - *Expired:* Inverted styling (white text on black background) or a high-contrast diagonal hatch pattern border.
- **Input Fields:** Minimalist design; a simple 1px bottom border that thickens to 2px black on focus. Labels are small, bold, and positioned above the field.
- **Cards/List Items:** Items are separated by thin horizontal rules (#E2E2E2). Large whitespace surrounds the product name and the expiry date.
- **Chips/Badges:** Small, rectangular with 2px radius. Use inverted colors (black fill) for high-priority alerts and light gray fill for categories.
- **Search Bar:** A persistent, fixed element with a subtle 1px border, utilizing a "glass" backdrop blur effect when scrolling to maintain context.